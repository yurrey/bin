const bininput = document.querySelector("#bin-number");

const cardshema = document.querySelector(".card-shema");

const cardlevel = document.querySelector(".card-level");

const cardtype = document.querySelector(".card-type");

const country = document.querySelector(".card-country");

const bank = document.querySelector(".card-bank");

const bankphone = document.querySelector(".bank-phone");

const bankurl = document.querySelector(".bank-url");


async function getdata(url) {
  // Default options are marked with *
  const response = await fetch(url, {
    'authority': 'lookup.binlist.net',
  'method': 'GET',
  'scheme': 'https',
'accept': 'application/json',
'accept-version': '3',
'origin':'https://binlist.net',
'referer': 'https://binlist.net/',
'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'Access-Control-Allow-Origin':  'http://127.0.0.1:5500',
'user-agent':'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
      });
  return response.json(); // parses JSON response into native JavaScript objects
}

function onlyNumberKey(evt) {
  // Only ASCII charactar in that range allowed
  var ASCIICode = evt.which ? evt.which : evt.keyCode;
  if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57)) return false;
  return true;
}


bininput.oninput = () => {
  document.querySelector('.loader').style.display = 'block'
  if (bininput.value.length == 8) {
    console.log('sent')
     
    
    getdata("https://lookup.binlist.net/" + bininput.value)
      .then((data) => {
   
      document.querySelector(".loader").style.display = "none";
        cardshema.textContent = data.scheme;
        cardlevel.textContent = data.brand;
        cardtype.textContent = data.type;
        country.textContent = data.country.name;
        bank.textContent = data.bank.name;
        bankphone.textContent = data.bank.phone;
        bankurl.textContent = data.bank.url;
        console.log(data.scheme);
      })
      .catch((error) => {
        console.error("Error:", error);
      });;
  }
};
